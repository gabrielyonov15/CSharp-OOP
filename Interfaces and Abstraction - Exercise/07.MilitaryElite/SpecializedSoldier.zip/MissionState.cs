﻿namespace MilitaryElite;
public enum MissionState
{
    InProgress,
    Finished
}