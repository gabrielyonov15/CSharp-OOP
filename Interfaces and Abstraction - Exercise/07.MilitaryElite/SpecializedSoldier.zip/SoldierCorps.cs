﻿namespace MilitaryElite;
public enum SoldierCorps
{
    Airforces,
    Marines
}