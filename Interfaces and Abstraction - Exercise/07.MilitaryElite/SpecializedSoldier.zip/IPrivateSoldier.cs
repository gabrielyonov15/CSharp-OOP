﻿namespace MilitaryElite;
public interface IPrivateSoldier : ISoldier
{
    decimal Salary { get; }
}